from django.apps import AppConfig


class IvideoPlayerConfig(AppConfig):
    name = 'ivideo_player'
